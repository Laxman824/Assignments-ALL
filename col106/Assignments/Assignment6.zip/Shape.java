

public class Shape implements ShapeInterface
{



}

