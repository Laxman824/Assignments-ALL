
interface EdgeInterface {

	//[(x1,y1,z1),(x2,y2,z2)]
	// 2 points for an edge which can be in any order

	PointInterface [] edgeEndPoints();

}

