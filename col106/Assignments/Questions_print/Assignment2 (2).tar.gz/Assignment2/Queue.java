// This class implements the Queue
public class Queue<V> implements QueueInterface<V>{

    //TODO Complete the Queue implementation
    private NodeBase<V>[] queue;
    private int capacity, currentSize, front, rear;
	
    public Queue(int capacity) {    
    
    }

    public int size() {
    
    }

    public boolean isEmpty() {
    
    }
	
    public boolean isFull() {
    
    }

    public void enqueue(Node<V> node) {
    
    }

    public NodeBase<V> dequeue() {
    
    }

}

