package RedBlack;

import Util.RBNodeInterface;

import java.util.List;

public class RedBlackNode<T extends Comparable, E> implements RBNodeInterface<E> {


    @Override
    public E getValue() {
        return null;
    }

    @Override
    public List<E> getValues() {
        return null;
    }
}
