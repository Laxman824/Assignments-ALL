package RedBlack;


public class RBTree<T extends Comparable, E> implements RBTreeInterface<T, E>  {


    @Override
    public void insert(T key, E value) {

    }

    @Override
    public RedBlackNode<T, E> search(T key) {
        return null;
    }
}