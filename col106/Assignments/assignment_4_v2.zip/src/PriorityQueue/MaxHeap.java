package PriorityQueue;

public class MaxHeap<T extends Comparable> implements PriorityQueueInterface<T> {


    @Override
    public void insert(T element) {

    }

    @Override
    public T extractMax() {
        return null;
    }

}