package ProjectManagement;

public class User implements Comparable<User> {


    @Override
    public int compareTo(User user) {
        return 0;
    }
}
