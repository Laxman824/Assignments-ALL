package ProjectManagement;

public class Job implements Comparable<Job> {

    @Override
    public int compareTo(Job job) {
        return 0;
    }
}