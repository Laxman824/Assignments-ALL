package Trie;


import Util.NodeInterface;


public class TrieNode<T> implements NodeInterface<T> {

    @Override
    public T getValue() {
        return null;
    }


}