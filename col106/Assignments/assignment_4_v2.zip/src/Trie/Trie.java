package Trie;

public class Trie<T> implements TrieInterface {


    @Override
    public boolean delete(String word) {
        return false;
    }

    @Override
    public TrieNode search(String word) {
        return null;
    }

    @Override
    public TrieNode startsWith(String prefix) {
        return null;
    }

    @Override
    public void printTrie(TrieNode trieNode) {

    }

    @Override
    public boolean insert(String word, Object value) {
        return false;
    }

    @Override
    public void printLevel(int level) {

    }

    @Override
    public void print() {

    }
}