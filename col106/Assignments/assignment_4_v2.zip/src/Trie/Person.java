package Trie;

public class Person {

    public Person(String name, String phone_number) {
    }

    public String getName() {
        return "";
    }
}
