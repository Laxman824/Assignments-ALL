//package COLASSIGN2;

public class EmptyStackException extends Exception {

	
	public EmptyStackException(String message) {
		super(message);
		
	}

	

}
 