package col106.assignment3.BST;

public class BST<T extends Comparable, E> implements BSTInterface<T, E>  {
	/* 
	 * Do not touch the code inside the upcoming block 
	 * If anything tempered your marks will be directly cut to zero
	*/
	public static void main() {
		BSTDriverCode BDC = new BSTDriverCode();
		System.setOut(BDC.fileout());
	}
	/*
	 * end code
	 * start writing your code from here
	 */
	
	//write your code here 
    public void insert(T key, E value) {
		//write your code here
    }

    public void update(T key, E value) {
		//write your code here
    }

    public void delete(T key) {
		//write your code here
    }

    public void printBST () {
		//write your code here
    }

}