package col106.assignment3.BST;

import java.util.List;

public abstract class BSTNode<T extends Comparable, E> implements BSTInterface<T, E> {


    public E getValue() {
        return null;
    }


}
