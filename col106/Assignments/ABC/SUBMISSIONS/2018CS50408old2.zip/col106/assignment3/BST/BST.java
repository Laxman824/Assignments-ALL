package col106.assignment3.BST;

import java.util.Queue;
import java.util.ArrayList;
import java.util.LinkedList;
 @SuppressWarnings("rawtypes")
class BSTNode<T extends Comparable,E extends Comparable> {
	 
			
			T key;
			E value;
			BSTNode left;
			BSTNode right;
			
			public BSTNode(T key, E value ) {
				this.key=key;
				this.value=value;
				this.left=null;
				this.right=null;
			}
			
			public E getvalue() {
				
			return value;
			}
			
			
			
			public  T getkey() {
				
				 return key;
			}
			@SuppressWarnings("unchecked")
			public BSTNode<T,E> getleft(){
				return left;
			}
			@SuppressWarnings("unchecked")
			public BSTNode<T,E> getright(){
				return right;
			}
			public void setvalue(E newvalue)
			{
				value=newvalue;
			}
			public void setKey(T newkey) {
				key=newkey;
			}
			public void setleft(BSTNode<T,E> newleft) {
				left=newleft;
			}
			public void setright(BSTNode<T,E> newright) {
				right=newright;
			}
			
			
		}


  

@SuppressWarnings("rawtypes")
public  class BST<T extends Comparable, E extends Comparable> implements BSTInterface<T, E>  {
	
	public static void main() {
		
		BSTDriverCode BDC = new BSTDriverCode();
		System.setOut(BDC.fileout());
	}
	//Start  from here.............
	 
	public BSTNode<T,E> root;
	
	public BST()
	{
		
		root = null;
	}
	
	
		public boolean searchfor(E value) {
			
			return searchfor1(root,value);
		}
	  
		@SuppressWarnings("unchecked")
		private   boolean  searchfor1(BSTNode<T,E> p, E value) {

			if(p == null) {// || p.value == value) {

				return false;
			}
			 if(p.getvalue().equals(value)) {
				
				return true;
				
			}
			if(value.compareTo(p.getvalue())< 0){	
													//as p is root node ,it should be > 0 
				return searchfor1(p.getleft(),value);
			}
			else {    
								//key > node's key then search in right side 
				return searchfor1(p.getright(),value);
			}
				
		 			
	}
	
	
	

    @SuppressWarnings("unchecked")
	public void insert(T key, E value) {
    	
			this.root = insert1(this.root,key,value);
		
    }
    	@SuppressWarnings({ "unchecked" })
		private BSTNode insert1(BSTNode root,T key,E value) {
    		
    		if(root == null) {
    			
    			BSTNode a = new BSTNode(key,value);
    				return a;
    				
    		}
    		else if(value.compareTo(root.getvalue()) < 0) {   ///

    			root.setleft(insert1(root.getleft(),key,value) );

    			
    		
    		}else {
    			
    			root.setright(insert1(root.getright(),key,value));
    			
    		}
    	return root;		
    	
    	}
  
    	
    	
   private  BSTNode min(BSTNode<T,E> q, BSTNode<T,E> par) {     //finding the leftest node in right side of root
   			
  	    if(q.getleft() == null) {				
  				par.left = q.right;
  	    	return q	;								// To find the min, go left as far as possible
  				
  				}else {

  					return min(q.getleft(), q);
  				}
  				
  		}
   @SuppressWarnings("unused")
private BSTNode min2(BSTNode r)
   
   {
	   BSTNode q = r;
	   
	   if(q.right.left== null) {      
		 
		   return q ;
	   }
	   else {
		   
		   q  = q.right;
		   
		   while(q.left.left != null) {
			   
			   q = q.left;
		 
		   }
		     
		   return q;
		   
	   }
	   
	   
   }
   
    	

   @SuppressWarnings("unchecked")
public void delete(T key) {
   	
   	BSTNode p = this.root;
   	
	ArrayList<BSTNode > bst_arraylist = new ArrayList<BSTNode >();
		
   	Queue <BSTNode> queue = new LinkedList<BSTNode>();   //creating empty node 
   	
   	queue.add(p);
   	
   while(!queue.isEmpty()) { //if queue is notempty pop a node and print 
   		
   	BSTNode<T,E> q = queue.poll();//poll used to check head and also remove it
		
   	bst_arraylist.add(q);
		
		if(q!=null) {    //as leftnode  is notnull we will add it to queue 
		
		if(q.left != null) queue.add(q.getleft());
		
		if(q.right != null) queue.add(q.getright());
   }
   }
   
   BSTNode dele_root = null;   ///show changed to dele_root
   
   BSTNode parent = null;
   
   for(int k= 0 ; k < bst_arraylist.size();k++) {
   	
   	if(bst_arraylist.get(k) != null && bst_arraylist.get(k).key.compareTo(key) == 0) {
   		
   		dele_root = bst_arraylist.get(k);
   		
   		break;
   	}
   }
   	if(dele_root == null)
   	{
   		return;
   	}
   	else
   		deleteNode(this.root,(E) dele_root.value);
   }
   
   
 
   
   
   
   
	public BSTNode deleteNode(BSTNode root, E key)
	{
		
		BSTNode parent = null;

		
		BSTNode curr_del = root;

		
		while (curr_del != null && curr_del.value != key)
		{
			
			parent = curr_del;

			
			if (key.compareTo(curr_del.value) < 0) {
				curr_del = curr_del.left;
			}
			else {
				curr_del = curr_del.right;
			}
		}

		
		if (curr_del == null) {
			return root;
		}

		// Case 1:it is a leaf node
		if (curr_del.left == null && curr_del.right == null)
		{
			
			if (curr_del != root) {
				if (parent.left == curr_del) {
					parent.left = null;
				} else {
					parent.right = null;
				}
			}
			
			else {
				root = null;
			}
		}

		// Case 2: two children
		else if (curr_del.left != null && curr_del.right != null)
		{
			BSTNode successor  = min(curr_del.right, curr_del);
			

			E val = (E) successor.value;
			T tkey = (T) successor.key;
		

			
			curr_del.value = val;
			curr_del.key = tkey;
			
	
		}
		// Case 3:  only one child
		else
		{
			
			BSTNode child = (curr_del.left != null)? curr_del.left: curr_del.right;

			if (curr_del != root)
			{
				
				if (curr_del == parent.left) {
					
					parent.left = child;
				
				} else {
					parent.right = child;
				}
					
					
				/*	
					
					BSTNode succ  = min(curr_del.right);
					
					BSTNode parentu = null;

					
					BSTNode curri = root;

					while (curri != null && curri.value != succ.value)
					{
						
						parentu = curri;
						
						if (succ.value.compareTo(curri.value) < 0) {
							curri= curri.left;
						}
						else {
							curri = curri.right;
						}
					
					
																										//parent.right = child;
				}
				                                             //deleteNode(root,(E) succ.value);	
					if(succ.right!=null) {
						
						parentu.left = succ.right;
					}else {
						parentu.left=null;
					}
					curr_del.value=succ.value;
					curr_del.key=succ.key;
					
					*/
				} 
			else {
				root = child;
			}
		}

		return root;
	}
   

   
 
    
   
	public void update(T key, E value) {
    	
    	
		
    	delete(key);
    	//delete((T) search(this.root,key).value);
    	
    	insert(key,value);
    	
    	
    	


	}																		
    private BSTNode search(BSTNode w , T key){     //find Node with given key and return it's value
    	
    	BSTNode p = this.root;
       	
    	ArrayList<BSTNode > bst_arraylist = new ArrayList<BSTNode >();
    		
       	Queue <BSTNode> queue = new LinkedList<BSTNode>();   //creating empty node 
       	
       	queue.add(p);
       	
       while(!queue.isEmpty()) { //if queue is notempty pop a node and print 
       		
       	BSTNode<T,E> q = queue.poll();//poll used to check head and also remove it
    		
       	bst_arraylist.add(q);
    		
    		if(q!=null) {    //as leftnode  is notnull we will add it to queue 
    		
    		queue.add(q.getleft());
    		
    		queue.add(q.getright());
       }
       }
       
       BSTNode dele_root = null;   ///show changed to dele_root
       
      
       
       for(int k= 0 ; k < bst_arraylist.size();k++) {
       	
       	if(bst_arraylist.get(k) != null && bst_arraylist.get(k).key.compareTo(key) == 0) {
       		
       		dele_root = bst_arraylist.get(k);
       		
       		break;
       	}
       }
	return dele_root;
    }

    public  void  printBST () {
    	
    	BSTNode<T,E> p = this.root;
    	
		ArrayList<BSTNode <T,E>> bst = new ArrayList<BSTNode <T,E>>();
		
    	Queue <BSTNode<T,E>> queue = new LinkedList<BSTNode<T,E> >();   //creating empty node 
    	
    	queue.add(p);
    	
    while(!queue.isEmpty()) { //if queue is notempty pop a node and print 
    		
    		BSTNode<T,E> q = queue.poll();//poll used to check head and also remove it
    		if(q == null) {
    			
    			//System.out.print("  "+q+ "  ");
    			break;
    		}
    		
    		else {
    			
    		System.out.println(q.key+", "+q.value);
    		}
    		
    		
    		bst.add(q);
    		
    		if(q!= null) {    //as leftnode  is notnull we will add it to queue 
    		
    		if(q.left != null) queue.add(q.getleft());
    		
    		if(q.right != null) queue.add(q.getright());
    }


    }
 //   System.out.println();
}
}



	