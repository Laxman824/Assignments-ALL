package col106.assignment3.Heap;
import java.util.Arrays;

public class Heap<T extends Comparable, E extends Comparable> implements HeapInterface <T, E> {

final int def_capacity=10;
E [] heap;
E [] keys;
int size;
boolean max;

	public static void main() {
		HeapDriverCode HDC = new HeapDriverCode();
		System.setOut(HDC.fileout());
	}


	public Heap() {

	heap =(E[]) new Comparable[def_capacity];
	keys = (E[]) new Comparable[def_capacity+1];
	size=0;
	max=true;
	
		}

	public Heap(boolean max) {
		
		heap=(E[]) new Comparable[def_capacity];
		size=0;
		this.max=max;
	}


	public boolean isEmpty()
	{
		return size==0;
	}
	
	public int length()
	{
		return size;
		
		
	}
	boolean hasparent(int i)
	{
		return i >1;
	}
	boolean hasleftchild(int i)
	{
		return leftIndex(i) <= size;
		
	}
	boolean hasrightchild(int i)
	{
		return rightIndex(i) <=size;
	}
	
	private int leftIndex(int i) {
		return (2*i) ;
		
	}
	private int rightIndex(int i)
	{
		return (2*i) + 1;
	}
	
	private int parentIndex(int i)
	{
		return i/2;
	}
	
	private E parent(int i)
	{
		return heap[parentIndex(i)];
	}
	
	
	public  E[] resize() {
		
		return Arrays.copyOf(heap, heap.length+def_capacity);
		
	}
	public E peek() {
		if(isEmpty()) throw new  IllegalStateException();
		return heap[1];
		
	}
	
	
	
	void swap(int index1,int index2) {
			
		E temp=heap[index1];
		heap[index1]=heap[index2];
		heap[index2]=temp;
	}
	
	
	
	public void bubbleUp() {
		
		int index=size;
		
			while(hasparent(index) && (parent(index).compareTo(heap[index])<0))
			{
				swap(index,parentIndex(index));
				
				index=parentIndex(index);
			}
		
	
	}
	public void bubbleDown()
	{
		int index=1;
		
		while(hasleftchild(index)  )
		{
			int larger=leftIndex(index);
			if(hasrightchild(index) && heap[leftIndex(index)].compareTo(heap[rightIndex(index)])<0)
			{
				larger=rightIndex(index);
			}
			
			if(heap[index].compareTo(heap[larger])<0) {
			
				
				swap(index,larger);
		
			}else break;
			
			index =larger;
			}
		}

public void insert(T key,E value) {
	
	
		keys[(int)key] = value;
		
		size++;
		
		heap[size]=value;
		
		bubbleUp();
	
}
	public 	E extractMax( ) {
		
		E result =peek();
		swap(1,size);
		heap[size]=null;
		size--;
		bubbleDown();
		System.out.println(result+"   extractedmax value");
		
		
		return result;
	}
	
	public 	void delete ( T key ) {
		
	
				E value = keys[(int)key];
				keys[(int)key] = null; 
				E temp = heap[size];
				size--;
				for(int i=1; i<=size; i++)
				{
					if(heap[i] == value)
					{
						heap[i] = temp;
						break;
					}
				}
				
				bubbleDown();
				
				bubbleUp();
				
			
		}

	public void increaseKey ( T key, E value ) {
	E temp = keys[(int)key];

	for(int i=1;i<=size;i++)
	{
		if(temp.equals(heap[i]))
		{
         	heap[i]=value;
         	keys[(int)key] = value;
	bubbleUp();
	bubbleDown();
		}
	
	}
	
}
	
	public void printHeap() {
		System.out.println("printing heap");
		for(int i=1; i <=size; i++) {
		
		 int j=0;
		 
		 for(j=0; j< keys.length; j++)
		 {
			 if(keys[j] == heap[i])
			 {
				 break;
			 }
		 }
		 System.out.print(j+", "+heap[i]);
		
		 System.out.println(); 
	    }
	
	  
	
	
}






	
}
