import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class TwoDBlockMatrix{

	
	 ArrayList<ArrayList<Float> > data =  new ArrayList<ArrayList<Float>>(0);
	 
	public static  TwoDBlockMatrix buildTwoDBlockMatrix( java.io.InputStream in ) {
		
		ArrayList<ArrayList<Float> > Array =  new ArrayList<ArrayList<Float>>(0); 
	     
		  Scanner s=new Scanner(in);
	      
		  String CurrentLine;
	      boolean start=false;
	      int row=0;
	      int col=0;
	      int prev_row=0;
	      int jump=0;
          int max_col=0;
	      while (s.hasNextLine()) {
	    	  	CurrentLine=s.nextLine();
	 
	    if (start==false) {
	      String[] arrSplit = CurrentLine.split(" ");
		  row=Integer.parseInt(arrSplit[0]);  //Integer.parseInt used to convert String to int
		  col=Integer.parseInt(arrSplit[1]);
		  jump=row-prev_row;
		  prev_row=row;
		  start=true;
		  
       }else if(CurrentLine.equals("#")) { // for String we use ".equals"  
	         
    	   if(s.hasNext()) {
		           CurrentLine = s.nextLine();
	        }else {
		      
	        	s.close();
		        
	        	break;
	   }
	  
	  String[] arrSplit = CurrentLine.split(" ");
	  
	  row=Integer.parseInt(arrSplit[0]);  //Integer.parseInt used to convert String to int
	  
	  col=Integer.parseInt(arrSplit[1]);
	  
	  jump=row-prev_row;
	   
	  prev_row=row;
	  
     }else {
		  
	 ArrayList<Float> Array1 =new ArrayList<Float>();
	 
	 for(int i=0; i <col-1;i++) {
	  
		 Array1.add((float) 0);
	   }
	   String[] to_add=CurrentLine.split(" ");
	   
	   int last_index = to_add.length-1;
	   
	   String[] rem_semi=to_add[last_index].split(";");  //remove semicolon in the given input
	   
	   to_add[last_index]=rem_semi[0];
	   
	   for(int i=0;i<to_add.length;i++) {
		           
		           Array1.add(Float.parseFloat(to_add[i]));   
	   }
	   if(max_col < Array1.size()) {
		   
		   max_col=Array1.size();
	   } 
	   
	   
	   for(int i=0;i<jump-2;i++) {
		   
		   ArrayList<Float> empty=new ArrayList<Float>();
		   Array.add(empty);
		  
	   }
	   
	   Array.add(Array1);
     }

   }
	   for(int i=0; i< Array.size();i++) {
	                int no_of_zeros;
	                no_of_zeros=max_col-Array.get(i).size();
	   for(int b=0;b < no_of_zeros; b++) {
		          Array.get(i).add((float) 0);      // Array.get used to Returns the element at the specified position in this list.
	   
	   }
	     
   }
	   
   float[][] matrix = new float[Array.size()][Array.get(0).size()];
   for(int i=0;i<Array.size();i++) {
	   for(int j=0;j<Array.get(i).size();j++) {
		   matrix[i][j]= Array.get(i).get(j);
	   }
   }
   TwoDBlockMatrix result = new TwoDBlockMatrix(matrix);
  
   return result;
  
  } 
   public TwoDBlockMatrix(float[][] other){
	   
	   int row=other.length;
	   int col=other[0].length;
	   data=new ArrayList<ArrayList<Float>>(0);
	   for(int i=0; i<row; i++) {
		   
		    ArrayList<Float> bot =new ArrayList<Float>(0);
	            
		       for(int j=0;j<col;j++) {
	            	
		                   bot.add(other[i][j]);
	                  
		       }
		       
	           data.add(bot);
	   }
   }
public TwoDBlockMatrix   transpose( ){
	
    ArrayList<ArrayList<Float>> newmatrix = new ArrayList<>();
    int rowCount = this.data.size();
    int colCount = 0;
       for(int i = 0; i < rowCount; i++){                  
                                                 //finding  maximum width
        ArrayList<Float> row = this.data.get(i);         
        
        int rowSize = row.size();
        if(rowSize > colCount){
            colCount = rowSize;
        }
        
        
    }
                                                         //for each row in the matrix
    for (int r = 0; r < rowCount; r++){
        ArrayList<Float>   innerIn = this.data.get(r);

                                                            //for each element in that row
             for (int c = 0; c < colCount; c++){

                                                             //add it to the outgoing matrix
                                                           //get newmatrix[c], or create it
            ArrayList<Float> matrixOutRow = new ArrayList<>();
            if (r != 0) {
                try{
                	
                    matrixOutRow = newmatrix.get(c);
                }
                catch(java.lang.IndexOutOfBoundsException e){
                    
                	System.out.println("Transposition error!\n" + "could not get matrixOut at index " + c + " - out of bounds" +e);
                    
                	matrixOutRow.add((float) 0);
                }
            }
        
            try{
            	
                matrixOutRow.add(innerIn.get(c));
            }  
            catch (java.lang.IndexOutOfBoundsException e){
            
            	matrixOutRow.add((float) 0);
            }
            
            try {
            	
            	newmatrix.set(c,matrixOutRow);                
            }
            catch(java.lang.IndexOutOfBoundsException e){
            	
            	newmatrix.add(matrixOutRow);
            }
        }
       
    }
    float[][] matrix = new float[newmatrix.size()][newmatrix.get(0).size()];
    
    for(int i=0;i<newmatrix.size();i++) {
 	      
    	   for(int j=0;j<newmatrix.get(i).size();j++) {
 		   
    		     matrix[i][j]= newmatrix.get(i).get(j);
 	   }
    }
    
    TwoDBlockMatrix result = new TwoDBlockMatrix(matrix);
    
    return result;
    
}

public TwoDBlockMatrix multiply (TwoDBlockMatrix other) throws IncompatibleDimensionException
{
	
  int a=this.data.size();
  int b=this.data.get(0).size();
  int p = other.data.size();
  int q = other.data.get(0).size();
  if(p!=b) {
	  throw new IncompatibleDimensionException("IncompatibleDimensionException");
  }
  else {
	  float[][] result=new float[a][q];

	  for (int i = 0; i < a; i++)

	    {
		for (int j = 0; j < q; j++)

		  {
			result[i][j] = 0;


		    for (int k = 0; k < p; k++)

		      {


			result[i][j] = result[i][j] + this.data.get(i).get(k) * other.data.get(k).get(j);
			
		      }
		    
		  }
	 
	    }
	  TwoDBlockMatrix resulta = new TwoDBlockMatrix(result);
	  return resulta;
  }
  
 
  
  
}
public  String toString (){
	return null;
}

public TwoDBlockMatrix inverse() throws InverseDoesNotExistException{
	
	return null;
	
}

public TwoDBlockMatrix getSubBlock ( int row_start, int col_start, int row_end, int col_end) throws SubBlockNotFoundException {
	return null;
	
}










/*public float[][] Inverse ()
{
  
	
	float det = 0;
	float mat[][] = new float[3][3];
	int a=Array.size();
  int b=Array.get(0).size();
  if(a!=b) {
	  System.out.println("edu.iitd.2020col106.InverseNotFoundException");
	  return null;
  
  }
  int q = Array.size() ;
  float[][] result=new float[q][q];
  for(int i = 0; i < 3; i++) {
      det = det + (mat[0][i] * (mat[1][(i+1)%3] * mat[2][(i+2)%3] - mat[1][(i+2)%3] * mat[2][(i+1)%3]));
	
	//System.out.println("\ndeterminant = " + det);
			
	//System.out.println("\nInverse of matrix is:");
	
	}
  return result;
	}
    */
  



  
  
  
  
 /*

public static void main(String[] args) throws FileNotFoundException {
	
	
	 try {
		 FileInputStream in =  new FileInputStream("C:\\Users\\k LAXMAN\\Desktop\\JAVA MODULE\\input.txt");
		 TwoDBlockMatrix xyz= buildTwoDBlockMatrix(in);
		 	 
	//	 System.out.println(xyz.data);
		// System.out.println(xyz.transpose().data);
		 
		 TwoDBlockMatrix type1 = xyz.multiply(xyz.transpose().data);
		//System.out.println ("Resultant matrix is"+ type1.data);


	 }
		
	 catch (IOException e) {

		   System.out.println("File not found ");
		   
		  
		  }
	
}  */
}

  

	 
 





 
 


 

	 

 

		
	
	
		
