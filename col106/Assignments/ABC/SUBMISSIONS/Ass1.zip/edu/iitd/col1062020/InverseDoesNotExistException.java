public class InverseDoesNotExistException extends Exception {
	public InverseDoesNotExistException(String s){
		super(s);
		}
}
