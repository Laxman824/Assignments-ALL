public class IncompatibleDimensionException extends Exception {
	public IncompatibleDimensionException(String s){
		super(s);
		}
}
