

import java.util.Iterator;

public interface Entity_ { 
	   public String name();                 
	   public Iterator<Student> studentList();      
	}