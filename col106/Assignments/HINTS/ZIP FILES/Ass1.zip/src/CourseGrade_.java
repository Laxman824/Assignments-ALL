

public interface CourseGrade_ {		
	   public String coursetitle();   	 
	   public String coursenum();   	
	   public GradeInfo_ grade();   	 
	   public String c_grade();
	}
