public class DH_HashTable<K,T> implements MyHashTable_<K,T>{
	
	Node<T>[] stud_arr;
	int arr_size;
	
	DH_HashTable(int size){
		stud_arr=new Node[size];
		arr_size=size;
		for(int i=0;i<size;i++) {
			stud_arr[i]=new Node<T>();
		}
	}
	// Hash function for first name.
	public long djb2(String str, int hashtableSize) { 
	    long hash = 5381; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = ((hash << 5) + hash) + str.charAt(i); 
	    } 
	    return Math.abs(hash) % hashtableSize; 
	}
	
	// Hash function for last name
	public long sdbm(String str, int hashtableSize) { 
	    long hash = 0; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = str.charAt(i) + (hash << 6) + (hash << 16) - hash; 
	    } 
	    return Math.abs(hash) % (hashtableSize - 1) + 1; 
	}
	
	public int hashfunc(int i,String a,String b) {
		int step;
		String c=a+b;
		step=(int) ((djb2(c,arr_size)+i*sdbm(c,arr_size))%arr_size);
		return step;
	}
	
	public int insert(K key, T obj) {
		String[] x=key.toString().split(" ");
		String fname=x[0];
		String lname=x[1];
		int i=0;
		int in_key=hashfunc(i,fname,lname);
		while(!(stud_arr[in_key].value()==null)) {
			i++;
			in_key=hashfunc(i,fname,lname);
		}
		stud_arr[in_key].set_val(obj);
		return i+1;
	}

	public int update(K key, T obj) {
		
		String[] x=key.toString().split(" ");
		String fname=x[0];
		String lname=x[1];
		int i=0;
		
		int in_key=hashfunc(i,fname,lname);
		String[] val=obj.toString().split(" ");
		while(stud_arr[in_key].value()==null){
			i++;
			in_key=hashfunc(i,fname,lname)%arr_size;
			if(i>arr_size) {
				return -1000;
			}
		}
		
		String[] stu=stud_arr[in_key].toString().split(" ");
		while(!(stu[0].equals(val[0])&&stu[1].equals(val[1]))) {
			i++;
			in_key=hashfunc(i,fname,lname)%arr_size;
		
			while(stud_arr[in_key].value()==null){
				i++;
				in_key=hashfunc(i,fname,lname)%arr_size;
			}
			stu=stud_arr[in_key].toString().split(" ");
			
			if(i>arr_size) {
				return -1000;
			}
		}
		stud_arr[in_key].set_val(obj);
		return i+1;
	}
	@Override
	public int delete(K key) {
		
		String[] x=key.toString().split(" ");
		String fname=x[0];
		String lname=x[1];
		
		int i=0;
		int in_key=hashfunc(i,fname,lname);
		while(stud_arr[in_key].value()==null) {
			i++;
			in_key=hashfunc(i,fname,lname);
			if(i>arr_size) {
				return -1000;
			}
		}
		String[] stu=stud_arr[in_key].toString().split(" ");
		while(!( stu[0].equals(fname) && stu[1].equals(lname) )) {
			i++;
			in_key=hashfunc(i,fname,lname);
			while(stud_arr[in_key].value()==null) {
				i++;
				in_key=hashfunc(i,fname,lname);
				if(i>arr_size) {
					return -1000;
				}
			}
			stu=stud_arr[in_key].toString().split(" ");
		}
		stud_arr[in_key].set_val(null);
		
		return i+1;
	}
	
	public boolean contains(K key) {
		
		String[] stu;
		String[] x=key.toString().split(" ");
		String fname=x[0];
		String lname=x[1];
	
		int i=0;
		int in_key=hashfunc(i,fname,lname);
		while(stud_arr[in_key].value()==null) {
			i++;
			in_key=hashfunc(i,fname,lname);
			if(i>arr_size) {
				return false;
			}
		}
		stu=stud_arr[in_key].toString().split(" ");
		while(stud_arr[in_key].value()==null || !(fname.equals(stu[0])&&lname.equals(stu[1]))) {
			
			i++;
			in_key=hashfunc(i,fname,lname);
			if(i>arr_size) {
				return false;
			}
			while(stud_arr[in_key].value()==null) {
				i++;
				in_key=hashfunc(i,fname,lname);
				if(i>arr_size) {
					return false;
				}
			}
			stu=stud_arr[in_key].toString().split(" ");
		}
		return true;
		

	}
	
	public T get(K key) throws NotFoundException {
		try {
			String[] x=key.toString().split(" ");
			String fname=x[0];
			String lname=x[1];
			int i=0;
			int in_key=hashfunc(i,fname,lname);
			
			while(stud_arr[in_key].value()==null) {
				i++;
				in_key=hashfunc(i,fname,lname)%arr_size;
				if(i>arr_size) {
					throw new NotFoundException();
				}
				
			}
			
			String[] stu=stud_arr[in_key].toString().split(" ");
			
			while(stud_arr[in_key].value()==null || !(fname.equals(stu[0])&&lname.equals(stu[1]))) {
		
				i++;
				in_key=hashfunc(i,fname,lname)%arr_size;
				if(i>arr_size) {
					throw new NotFoundException();
				}
				while(stud_arr[in_key].value()==null) {
					i++;
					in_key=hashfunc(i,fname,lname)%arr_size;
					if(i>arr_size) {
						throw new NotFoundException();
					}
					
				}
				stu=stud_arr[in_key].toString().split(" ");
				
			}
			
			return stud_arr[in_key].value();
			}catch(NotFoundException e) {
				System.out.println("E");
				return null;
			}
	}
	
	public String address(K key) throws NotFoundException {
		try {
			String[] x=key.toString().split(" ");
			String fname=x[0];
			String lname=x[1];
			int i=0;
			int in_key=hashfunc(i,fname,lname);
			while(stud_arr[in_key].value()==null) {
				i++;
				in_key=hashfunc(i,fname,lname);
				if(i>arr_size) {
					throw new NotFoundException();
				}
			}

			String[] stu=stud_arr[in_key].toString().split(" ");
			while(stud_arr[in_key].value()==null || ! (fname.equals(stu[0]) && lname.equals(stu[1]))) {
				i++;
				in_key=hashfunc(i,fname,lname)%arr_size;
				if (i>arr_size) {
					throw new NotFoundException();
				}
				while(stud_arr[in_key].value()==null) {
					i++;
					in_key=hashfunc(i,fname,lname);
					if(i>arr_size) {
						throw new NotFoundException();
					}
				}

				stu=stud_arr[in_key].toString().split(" ");
			}
			return in_key+"";
			}catch(NotFoundException e) {
				System.out.println("E");
				return null;
			}
	}
	
	
}
