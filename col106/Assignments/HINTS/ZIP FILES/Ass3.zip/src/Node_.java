

public class Node_<T> implements Comparable<Node_<T>> {
	T student;
	Node_<T> l_next;
	Node_<T> r_next;
	Node_<T> prev;
	Node_(T val){
		student=val;
		prev=null;
	}
	public T value() {
		return student;
	}
	public Node_<T> prev(){
		return prev;
	}
	public void set_prev(Node_<T> node) {
		prev=node;
	}
	public boolean isleaf() {
		if(l_next==null && r_next==null) {
			return true;
		}else {
			return false;
		}
	}
	public Node_<T> l_next() {
		return l_next;
	}
	public Node_<T> r_next() {
		return r_next;
	}
	public void udate(Node_<T> T) {
		this.student=T.value();
	}
	public int compareTo(Node_<T> o) {
		T stud=o.value();
		T val=this.value();
		String[] va=val.toString().split(" ");
		String[] stu=stud.toString().split(" ");
		return va[0].compareTo(stu[0]);
	}
	public int compareTo2(Node_<T> o) {
		T stud=o.value();
		T val=this.value();
		String[] va=val.toString().split(" ");
		String[] stu=stud.toString().split(" ");
		return va[1].compareTo(stu[1]);
	}
	
	public void set_l_next(Node_<T> n) {
		this.l_next=n;
	}
	public void set_r_next(Node_<T> n) {
		this.r_next=n;
	}
	public int num_of_children(){
		if (l_next==null && r_next==null) {
			return 0;
		}else if(l_next!=null && r_next!=null) {
			return 2;
		}else {
			return 1;
		}
	}
	public void set_value(T x) {
		this.student=x;
	}
}

