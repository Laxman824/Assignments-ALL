package ProjectManagement;

public interface UserReport_ {
   String user();
   int consumed();
}

