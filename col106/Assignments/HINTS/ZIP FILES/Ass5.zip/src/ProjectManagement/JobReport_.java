package ProjectManagement;

public interface JobReport_ {
   String user();
   String project_name();
   int budget();
   int arrival_time();
   int completion_time();
}

