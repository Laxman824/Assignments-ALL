package ProjectManagement;

public class Project {
	String name;
	int budget;
	int priority;
	Project(String name,int priority,int budget){
		this.name=name;
		this.budget=budget;
		this.priority=priority;
	}
}
