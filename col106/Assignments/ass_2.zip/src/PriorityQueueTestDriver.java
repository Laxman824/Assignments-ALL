// Use this driver for the testing the correctness of your priority queue implementation
// You can change the add, remove sequence to test for various scenarios.
public class PriorityQueueTestDriver {
    public static void main(String[] args) {
	Queue<String> pq = new Queue<String>(5);
	//System.out.println(pq.size());
	pq.enqueue(new Node(4, "A"));
	//System.out.println(pq.size());
	//System.out.println(pq.size());
	
	pq.enqueue(new Node(10, "B"));
	//System.out.println(pq.size());
	pq.enqueue(new Node(3, "C"));
	//System.out.println(pq.size());
	pq.enqueue(new Node(5, "E"));
	//System.out.println(pq.size());
	pq.enqueue(new Node(2, "F"));
	/*System.out.println(pq.size());
	System.out.println(pq.dequeue().getPriority());
	/*System.out.println(pq.size()+"a");
	System.out.println(pq.dequeue().getPriority());
	System.out.println(pq.size()+"a");
	System.out.println(pq.dequeue().getPriority());
	System.out.println(pq.size()+"a");
	System.out.println(pq.dequeue().getPriority());
	System.out.println(pq.size()+"a");
	System.out.println(pq.dequeue().getPriority());
	System.out.println(pq.size()+"a");*/


	
	

	int size = pq.size();
	for (int i=0; i<size; i++) {
		//System.out.println("b"+i);
		
            Node<String> n = (Node<String>) pq.dequeue();
          n.show();
	}
    }
}



