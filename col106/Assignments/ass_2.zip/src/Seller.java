import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Seller<V> extends SellerBase<V> {
	
    public Seller (int sleepTime, int catalogSize, Lock lock, Condition full, Condition empty, PriorityQueue<V> catalog, Queue<V> inventory) {
    	 this.lock=lock;
         this.full=full;
         this.empty=empty;
         this.catalog=catalog;
         this.inventory=inventory;
         this.setSleepTime(sleepTime);
    	
        //TODO Complete the constructor method by initializing the attributes
        // ...
    }
    
    public void sell() throws InterruptedException {
	try {lock.lock();
	while(catalog.isFull()) {
		full.await();
	}
	if(inventory.isEmpty() == false) {
	
	catalog.enqueue((Node<V>)inventory.dequeue());
	empty.signalAll();
	
            //TODO Complete the try block for produce method
            // ...
	}
	} catch(Exception e) {
            e.printStackTrace();
	} finally {
            lock.unlock();
	}		
    }
}
