                                    2018CS50408
                                     K.LAXMAN
                                   Assignment 2
      
Expalnaion about the code written :


1) Queue:I have implemented a class called Queue and defined variables  of Scope private as Node base,capacity,currentSize,
front,rear.
defined Queue  with capacity and functions to return the currentSize.
isEmpty function to return if the currentSize==0 and isFull function to check whether the queue is full using if currentSize==capcity

enqueue :(insertion of elements into the queue)
first we will check whether the queue is Full and if its not ,elements will be inserted from rear  side (I didnt mention in the code whether it is rear or front but just assuming )


dequeue: (deletion of elements from the queue )
Firstly ww will check whether the currentSize==0 then null ,if not then element will be deleted from the front sie 
  
Priority queue:

Priority queue is same as queue but some of the dissimilarities
enqueue of the elements is will be done randomly int the queue.

dequeue : deletion of elements will be different  i.e.first the elements with the highest priority (which  element has minindex)
will be deleted as per the priority

Buyer :
In buyer ,I have defined a constructor buyer and defined lock,full ,empty,setIteration and  sleepTtime
we are synchronizing by method lock and we are giving the key of the lock in the seller
class and simultaneously we are dequeueing from catalog


Seller:

In Seller as usual same constructor has been defined with lock,full ,empty,setIteration and  sleepTtime
we are synchronizing by method lock and we are giving the key of the lock in the buyer
class and simultaneously we are removing elements from inventory and adding into catalog 




Node:

defined a class Node which returns the getPriority and value 
it is used in  the Assignment2Driver code for further running of the program.


Assignment2Drive:

I have defined a class Assignment2Driver  with variables catalogSize,numBuyers,numSellers,sellersSleepTime,
seller class and Buyer class has been initialised in these Assignment2Driver 
inventory has been defined in Driver and it runs using the input values.






