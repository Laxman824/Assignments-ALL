
public class PriorityQueue<V> implements QueueInterface<V>{

    private NodeBase<V>[] queue;
    private int capacity, currentSize;
	
    //TODO Complete the Priority Queue implementation
    // You may create other member variables/ methods if required.
    public PriorityQueue(int capacity) {
    	this.capacity=capacity;
    	queue=new NodeBase[capacity];
    }

    public int size() {
    	return currentSize;
    
    }

    public boolean isEmpty() {
    	return (currentSize==0);
 
    }
	
    public boolean isFull() {
    	return (currentSize==capacity);

    }

    public void enqueue(Node<V> node) {
    	if(!this.isFull()) {
    	queue[currentSize]=node;
    	currentSize++;
    	}
    }

    // In case of priority queue, the dequeue() should 
    public NodeBase<V> dequeue(){
    	if(currentSize == 0)
    		return null;
    	int minindex = 0;
    	for(int i = 1 ; i < currentSize ; i++) {
    		if(queue[i].getPriority() <= queue[minindex].getPriority() ) {
    			minindex = i;
    		}
    		
    	}
    	NodeBase<V> min = queue[minindex];
    	for(int i = minindex; i < currentSize - 1 ;i++) {
    		queue[i] = queue[i+1];
    	}
    	currentSize--;
    	return min;
    }
    public void display () {
	if (this.isEmpty()) {
            System.out.println("Queue is empty");
	}
	for(int i=0; i<currentSize; i++) {
            queue[i+1].show();
	}
    }
}

