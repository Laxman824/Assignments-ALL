// This class implements the Queue
public class Queue<V> implements QueueInterface<V>{

    //TODO Complete the Queue implementation
    private NodeBase<V>[] queue;
    private int capacity, currentSize, front, rear;
	
    public Queue(int capacity) {
    	this.capacity=capacity;
    	queue=new NodeBase[capacity];
    }

    public int size() {
    	return currentSize;
    
    }

    public boolean isEmpty() {
    	return (currentSize==0);
    
    }
	
    public boolean isFull() {
    	return (currentSize==capacity);
    
    }

    public void enqueue(Node<V> node) {
    	if(!this.isFull()) {
    	NodeBase<V> n = node;
    	queue[currentSize]=n;
    	currentSize++;
    	}
    }

    public NodeBase<V> dequeue() {
    	if(currentSize == 0)
    		return null;
    	NodeBase<V> temp = queue[0];
        for(int i=0;i<currentSize-1;i++) {
    		queue[i]=queue[i+1];
    		
    	}
    	currentSize--;
        return temp;
    	
    
    }

}

