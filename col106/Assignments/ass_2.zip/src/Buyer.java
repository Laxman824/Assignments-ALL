import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Buyer<V> extends BuyerBase<V> {
    public Buyer (int sleepTime, int catalogSize, Lock lock, Condition full, Condition empty, PriorityQueue<V> catalog, int iteration) {
        this.lock=lock;
        this.full=full;
        this.empty=empty;
        this.catalog=catalog;
        this.setIteration(iteration);
        this.setSleepTime(sleepTime);
    }
    public void buy() throws InterruptedException {
    	
	try {lock.lock();
	while(catalog.isEmpty()) {
		empty.await();
	}
	NodeBase<V> n = catalog.dequeue();
		
            System.out.print("Consumed "); // DO NOT REMOVE (For Automated Testing)
            n.show(); // DO NOT REMOVE (For Automated Testing)
            full.signalAll();
            
	} catch (Exception e) {
            e.printStackTrace();
	} finally {
		lock.unlock();
            
	}
    }
}
