use std::env;
use std::fmt;
use std::fs;
use std::io::stdin;

#[derive(Debug)]
struct State {
	pc: usize,
	accum: usize,
	mbox: [usize; 100],
	neg_flag: bool,
	reg: [usize; 6],
}

impl fmt::Display for State {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(f, "PC: {}, accum: {}, neg_flag: {}, reg: {:?}, mbox: ", self.pc, self.accum, self.neg_flag, self.reg)?;
	for i in 0..10 {
		let l = i*10;
		for j in l..l+10 {
			write!(f, "{}:{}\t", j, self.mbox[j]);
		}
		writeln!(f, "");
	}
	Ok(())
    }
}

fn load(file_path: &String) -> State {
	
}

/* Returns if the program has finished */
fn run(state: &mut State) -> bool {
	false
}
 
fn main() -> Result<(), String> {
	let args: Vec<String> = env::args().collect();
	let file_path = args.get(1).ok_or("Required file path")?;

	// Load the program
	let mut state = load(file_path);
		
	// Run the program
	run(&mut state);
	
	Ok(())
}