import random

count =0
count1 =0
for i in range(1000):
    y = 0.9
    x = random.uniform(0,1)
    

    if y >x :
    #  print (True)
      count +=1
    
    
    else:
   #   print (False)
      count1 += 1
print( count, "Number of True statements")
print(count1, "Number of False statements")
