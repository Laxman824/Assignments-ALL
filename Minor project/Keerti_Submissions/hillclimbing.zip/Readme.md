python3 hillclimbing.py

