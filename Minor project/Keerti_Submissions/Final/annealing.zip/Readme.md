python3 annealing.py
python3 hillclimbing.py

